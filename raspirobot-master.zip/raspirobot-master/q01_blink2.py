# q01_blink2.py
# This program blinks each LEDs alternately 

# Modified by Bart ... added try, except and finally clauses.

import time
from rrb3 import *

rr = RRB3()

print("Press CTRL-c to quit the program")

try:
    while True:
        rr.set_led1(1)
        rr.set_led2(0)
        time.sleep(0.5)
        rr.set_led1(0)
        rr.set_led2(1)
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\n\nProgam ending")

finally:
    print("Cleaning up GPIO")
    rr.cleanup()
