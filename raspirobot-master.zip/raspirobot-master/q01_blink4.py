# q01_blink4.py
# This program blinks the LEDs randomly at random timed intervals

# Modified by Bart ... added try, except and finally clauses.

import time
import random
from rrb3 import *

rr = RRB3()

print("Press CTRL-c to quit the program")

try:
    while True:
        rr.set_led1(random.randint(0,1))
        rr.set_led2(random.randint(0,1))
        time.sleep(random.uniform(0,0.2))

except KeyboardInterrupt:
    print("\n\nProgam ending")

finally:
    print("Cleaning up GPIO")
    rr.cleanup()
