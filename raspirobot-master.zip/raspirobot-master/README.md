# robot3
# Bart's version of raspirobot3 files
# Modified (as/if needed) to execute with Python3 instead of Python2
#

Original README.md
-------------------

# raspirobot3

Project files for the Monk Makes RasPiRobot Rover Kit.

A collaboration between Alan O'Donohoe (@teknoteacher) and MonkMakes.com (@monkmakes)

-------------------

Bart's changes:

# Copied squid.py into current directory
# Copied rrb3.py and rrb3.pyc into current directory
# For each modified program, rename to begin with a 'q' (for quahog)
# Added try/except/finally clauses to 'q' programs.
# try: contains original logic
# except: traps crl-c
# finally: executes GPIO.cleanup() when programs end

