myfile = open('mytest.fil','r')
for x in myfile:
    print(x)
    
